//
//  File.swift
//  
//
//  Created by Юлия Гудошникова on 30.04.2024.
//

import Vapor

extension UUID: Content {}
