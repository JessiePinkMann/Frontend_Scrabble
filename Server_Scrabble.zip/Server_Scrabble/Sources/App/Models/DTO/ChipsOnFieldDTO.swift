//
//  File.swift
//  
//
//  Created by Юлия Гудошникова on 30.04.2024.
//

import Foundation

// Фишка на поле
struct ChipsOnFieldDTO: Codable {
    var coordinate: Coordinate
    var chip: Chip
}
