//
//  Coordinate.swift
//
//
//  Created by Юлия Гудошникова on 29.04.2024.
//

// Координата
struct Coordinate: Codable {
    let x: String;
    let y: Int;
}
