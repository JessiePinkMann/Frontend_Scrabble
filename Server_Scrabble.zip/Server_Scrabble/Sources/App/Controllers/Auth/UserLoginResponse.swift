import Vapor

struct UserLoginResponse: Content {
    let id: String
    let JWT: String
    
    init(id: String, JWT: String) {
        self.id = id
        self.JWT = JWT
    }
}
